package com.example.votingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btnSubmit;
    EditText Name,Aadhar,Age;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSubmit=findViewById(R.id.button);
        Name=findViewById(R.id.name);
        Aadhar=findViewById(R.id.aadhar);
        Age=findViewById(R.id.age);
        btnSubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String namep=Name.getText().toString();
                String aadharp=Aadhar.getText().toString();
                String agep=Age.getText().toString();
                Intent intent=new Intent(getApplicationContext(),VotingApp2.class);
                intent.putExtra("namep",namep);
                intent.putExtra("aadharp",aadharp);
                intent.putExtra("agep",Double.parseDouble(agep));
                startActivity(intent);
           }
        });
    }
}