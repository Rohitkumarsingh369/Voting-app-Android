package com.example.votingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class VotingApp2 extends AppCompatActivity {
    TextView Namedisplay;
    TextView Aadhardisplay;
    TextView Agedisplay;
    TextView eligibledisplay;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting_app2);
        Namedisplay=findViewById(R.id.namedisplay);
        Aadhardisplay=findViewById(R.id.aadhardetail);
        Agedisplay=findViewById(R.id.agedisplay);
        eligibledisplay=findViewById(R.id.eligible);
        Intent intent=getIntent();
        String name=intent.getStringExtra("namep");
        Double age=intent.getDoubleExtra("agep",0);
        String aadhar=intent.getStringExtra("aadharp");
        Namedisplay.setText(name);
        Aadhardisplay.setText("Aadhar Number: "+aadhar);
        Agedisplay.setText("Age: "+age);

        if(age>=18){
            result="Eligible";
        }
        else{
            result="Not Eligilble";
        }
        eligibledisplay.setText("You are "+result+" to vote");
    }
}